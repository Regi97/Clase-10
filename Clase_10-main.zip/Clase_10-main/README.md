# PROC50-1_4-Referencia-alumno2
Dispara al zombi  

Lesson Plan Activity  
### Texto en inglés: C42-zombie-killer-1
